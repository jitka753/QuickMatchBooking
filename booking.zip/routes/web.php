<?php
use App\Http\Middleware\CheckStatus;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@index');


Auth::routes();

Route::get('/prnpriview', 'ListBookingsController@prnpriview');
Route::resource('/listbookings', 'ListBookingsController');
//Route::get('/mybooking', 'PagesController@mybooking');
Route::post('/mybooking/book', 'BookingsController@updateBooking')->name('updatemybooking');

Route::get('/mybooking/unbook/{booking}', 'BookingsController@cancelBooking')->name('cancelbooking');
Route::resource('/mybooking', 'BookingsController');
//Route::get('/mybooking', 'BookingsController@getTimeSlots($id_company)');
Route::group(['middleware' => CheckStatus::class], function(
    ){
        Route::resource('/admin', 'AdminController');
        Route::resource('/addcompany', 'CompanyAdminController');
        Route::resource('/companyevent', 'CompanyEventController');
        Route::resource('/allstudents', 'AllStudentsController');
        Route::resource('/companystudent', 'StudentCompanyAdminController');

    });

