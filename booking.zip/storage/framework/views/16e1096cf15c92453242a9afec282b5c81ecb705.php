<?php $__env->startSection('content'); ?>
<h1>Add New Company</h1>
<div class="container">
<?php echo Form::open(['action' => 'CompanyAdminController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>


    <!-- company name-->
    <div class="form-group">
        <label>Company Name*</label>
        <?php echo e(Form::text('companyName', '', ['class' =>'form-control', 'placeholder' => 'Enter company name'])); ?>

    </div>


    <!-- Company email-->
    <div class="form-group">
        <label for="exampleInputEmail1">Company Email Address*</label>
        <?php echo e(Form::text('companyEmail', '', ['class' =>'form-control', 'placeholder' => 'Enter company email'])); ?>

    </div>

    <!-- company phone-->
    <div class="form-group">
        <label>Company Phone*</label>
        <?php echo e(Form::text('companyPhone', '', ['class' =>'form-control', 'placeholder' => 'Enter company phone number. Example: +45 91 19 16 90'])); ?>

    </div>

    <!-- company mobile-->
    <div class="form-group">
        <label>Company Mobile*</label>
        <?php echo e(Form::text('companyMobile', '', ['class' =>'form-control', 'placeholder' => 'Enter company mobile number. Example: +45 91 19 16 90'])); ?>

    </div>

    <!-- company address-->
    <div class="form-group">
        <label>Company Address*</label>
        <?php echo e(Form::text('companyAddress', '', ['class' =>'form-control', 'placeholder' => 'Enter company address'])); ?>

    </div>
  

    <!-- company description -->
    <div class="form-group">
            <label for="companyDescription">Company Description*</label>
            <?php echo e(Form::textarea('companyDescription', '', ['class' =>'form-control', 'placeholder' => 'Describe the company'])); ?>

    </div>

     <!-- company website-->
     <div class="form-group">
            <label>Company Website*</label>
            <?php echo e(Form::text('companyWebLink', '', ['class' =>'form-control', 'placeholder' => 'Enter company website'])); ?>

    </div>

     <!-- company responsible person name-->
     <div class="form-group">
            <label>Responsible Person Name*</label>
            <?php echo e(Form::text('companyResPerson', '', ['class' =>'form-control', 'placeholder' => 'Enter name of responsible person'])); ?>

    </div>

     <!-- company responsible person phone-->
     <div class="form-group">
            <label>Responsible Person Phone*</label>
            <?php echo e(Form::text('companyPhoneRP', '', ['class' =>'form-control', 'placeholder' => 'Example: +45 91 19 16 90'])); ?>

    </div>

     <!-- company responsible person email-->
     <div class="form-group">
            <label>Responsible person email*</label>
            <?php echo e(Form::text('companyEmailRP', '', ['class' =>'form-control', 'placeholder' => 'Enter email of responsible person'])); ?>

    </div>
    <div>
    <small>*Required fields</small>
    </div>

    <!-- submit and close form-->
    <?php echo e(Form::submit('Submit', ['class'=> 'btn btn-primary'])); ?>

    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>