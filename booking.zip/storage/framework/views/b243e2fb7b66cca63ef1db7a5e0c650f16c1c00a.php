<?php $__env->startSection('content'); ?>
    <h1>List of <?php echo e(Auth::user()->name); ?> <?php echo e(Auth::user()->studentLastName); ?>'s bookings</h1>
    <?php if(count($time_slots) >0): ?> 
    <table class="table table-bordered">
        <thead>
          <tr>
                <?php 
                $number_row=1;
                ?>
            <th scope="col"></th>
            <th scope="col">Time</th>
            <th scope="col">Company</th>
          </tr>
        </thead>
        <tbody>
          <tr>
             <?php $__currentLoopData = $time_slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timeslot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php 
              $fulltime=substr(($timeslot->time_slot_value),0,5);
              $endTime = strtotime("+5 minutes", strtotime($timeslot->time_slot_value)); 
             ?>
            <th scope="row"><?php echo e($number_row); ?></th>
          <td><?php echo e($fulltime); ?> - <?php echo e(date('g:i',$endTime)); ?></td>
          <td><?php echo e($timeslot->companyName); ?></td>
          <?php 
          $number_row++;
          ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>