<?php $__env->startSection('content'); ?>
    <h1>Company-students</h1>
    <?php if(count($companies) >0): ?> 
    <table id="printable" class="table table-bordered">
        <thead>
          <tr>
                <?php 
                $number_row=1;
                ?>
            <th scope="col"></th>
            <th scope="col">Company</th>
          </tr>
        </thead>
        <tbody>
          <tr>
             <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th scope="row"><?php echo e($number_row); ?></th>
          <td> <h3><a href="/companystudent/<?php echo e($company->id_company); ?>"><?php echo e($company->companyName); ?></a></h3></td>
          <?php 
          $number_row++;
          ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>

    <br><br>



    <a class="btn btn-primary" role="button" href="javascript:window.print()">Print</a>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>