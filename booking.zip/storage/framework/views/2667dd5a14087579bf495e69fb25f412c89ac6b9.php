<?php $__env->startSection('content'); ?>
<h1>All Students</h1>

<?php if(count($students) >0): ?> 
    <table id="printable" class="table table-bordered">
        <thead>
          <tr>
                <?php 
                $number_row=1;
                ?>
            <th scope="col"></th>
            <th scope="col">First Name</th>
            <th scope="col">Last Name</th>


          </tr>
        </thead>
        <tbody>
          <tr>
             <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <th scope="row"><?php echo e($number_row); ?></th>
          <td><?php echo e($student->name); ?></td>
          <td><?php echo e($student->studentLastName); ?></td>
          <?php 
          $number_row++;
          ?>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php endif; ?>

    <br><br>

    <a href="javascript:window.print()">Print</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>