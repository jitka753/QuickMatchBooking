<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-4 offset-md-4">
        <h1 class="text-center">My Bookings</h1>
    </div>
    <div class="col-md-2 offset-md-2">
        <!--select event -->
        <label>Select event: <?php echo Form::select('dropdownCity', $eventsDropDown); ?></label>
    </div>
</div>
<div class="text-center">
    <div class="alert alert-default alert-dismissible fade show" role="alert">
        <strong>Rules:</strong>
        Maximum one booking per company.
        Maximum one interview per time-slot.
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
      </div>
</div>
<!--loop companies, beginning of form -->
 <?php if(count($companies) >0): ?>

<form name="myForm" id="myForm" method="POST" action="<?php echo e(route('updatemybooking')); ?>" onsubmit="return validateForm()">
    <?php echo e(csrf_field()); ?>


    <!-- access user id-->
    <?php if(auth()->guard()->guest()): ?>

    <?php else: ?>
    <input type="hidden" name="id" value="<?php echo e(Auth::user()->id); ?>">
    <?php endif; ?>

    <?php $companyTime=-1;
    $bookingId=-1;
    ?>
    <input type="hidden" name="id_event" value="1">
    <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $companyTime++;
    ?>
    <ul class="list-group list-group-flush">
        <li class="list-group-item" id="tableRow_<?php echo e($company->id_company); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-md-1">
                        <button type="button" class="btn btn-primary span4" data-toggle="modal" data-target="#exampleModalCenter_<?php echo e($company->id_company); ?>">Details</button>
                    </div>
                    <div class="col-md-6">
                        <h3><?php echo e($company->companyName); ?></h3>
                    </div>
                </div>
                <br>


                <div class="row">
                <table class="table  table-bordered ">
                    <?php
                    $row_count=0;
                    $col_count=0;
                    //while($rowpost = mysqli_fetch_array($respost)) {
                    if($row_count%4==0){
                    echo "<tr>";
                        $col_count=1; }
                        ?>
                        <!-- loop through time-slots-->
                        <tbody>
                            
                            <?php ?>
                            <div class="col-sm-3">
                                <tr>
                                    <?php $__currentLoopData = $time_slots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time_slot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(($company->id_company) === ($time_slot->id_company)): ?>

                                    <!-- time-formatting, add 5 minutes to each time-->
                                    <?php
                                    $cleantime=substr(($time_slot->time_slot_value),0,5);
                                    $endTime = strtotime("+5 minutes", strtotime($time_slot->time_slot_value));
                                    $counter = 0;
                                    ?>
                                    <input type="hidden" name="id_booking" value="<?php echo e($time_slot->id_booking); ?>">
                                    <td class='span4'>
                                        <label>

                                            <!--add invisible radio button behind each table cell-->
                                            <input type="checkbox" class="radio click-input" name="<?php echo e($company->id_company); ?>"
                                                data-booking_id="<?php echo e($time_slot->id_booking); ?>" value="<?php echo e($time_slot->id_time_slot); ?>" />
                                            <div class="oneField">
                                                <?php echo e(($cleantime)); ?> - <?php echo e(date('g:i', $endTime)); ?>

                                            </div>
                                        </label>
                                    </td>

                                    <?php
                                    if($col_count==9){
                                    echo "
                                </tr>";
                                }
                                $row_count++;
                                $col_count++;
                                ?>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>

                </table>
              </div>
                <?php if($company_time[$company->id_company]['booking'] != 0) :?>

                <?php
                $cleantime=substr(($company_time[$company->id_company]['timeslot']),0,5);
                $endTime = strtotime("+5 minutes", strtotime($company_time[$company->id_company]['timeslot']));
                ?>

                <!-- $x = SELECT id_time_slot FROM bookings WHERE ...........

    change $x id_time_slot to real time.
    -->     <div class="container">
                <div class="col-md-3,1 pull-right">
                    <label>Booked time: </label>
                    <?php echo e($company_time[$company->id_company]['timeslot']); ?> - <?php echo e(date('g:i', $endTime)); ?>


                    <a href="<?php echo e(route('cancelbooking', ['booking' => $company_time[$company->id_company]['booking']])); ?>"
                        class="btn btn-primary cancel">Cancel</a>
                    <?php else: ?>
                    <input type="hidden" name="company_<?php echo e($company->id_company); ?>" id="company_<?php echo e($company->id_company); ?>">
                    <?php endif; ?>
                </div>
                <span id="spnText"></span>
        </li>


        <!-- Modal pop up window-->

        <div class="modal fade" id="exampleModalCenter_<?php echo e($company->id_company); ?>" tabindex="-1" role="dialog"
            aria-labelledby="exampleModalCenterTitle" aria-hidden="true">

            <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
                <div class="modal-content">
                    <div class="modal-header">


                        <!-- display company name/details-->
                        <h5 class="modal-title" id="exampleModalLongTitle"><?php echo e($company->companyName); ?></h5>

                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <?php echo e($company->companyDescription); ?>

                        <hr>
                        <h5>Website link</h5>
                        <p><a href="<?php echo e($company->companyWebLink); ?>"><?php echo e($company->companyWebLink); ?></a></p>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!--submit form -->
        <footer class="fixed-bottom">
            <div class="container">
                <button type="submit" class="btn btn-primary btn-lg btn-block">Submit</button>
            </div>
        </footer>
</form>


<script type="text/javascript">
    $('.click-input').click(function () {
        if ($(this).is(":checked")) {
            $('#company_' + $(this).attr('name')).val($(this).data('booking_id'));
        } else {
            $('#company_' + $(this).attr('name')).val('');
        }
    });
</script>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>