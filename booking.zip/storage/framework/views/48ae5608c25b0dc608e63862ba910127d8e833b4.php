<?php $__env->startSection('content'); ?>
<a href="/companystudent" class="btn btn-primary" role="button">Go Back</a>
<h1  class="text-center"><?php echo e($company->companyName); ?></h1>
<h3  class="text-center">Students that are signed up</h3>

<?php if(count($companystudents) >0): ?> 
<table id="printable" class="table table-bordered">
    <thead>
      <tr>
            <?php 
            $number_row=1;
            ?>
        <th scope="col"></th>
        <th scope="col">Booked Time</th>
        <th scope="col">First Name</th>
        <th scope="col">Last Name</th>
      </tr>
    </thead>
    <tbody>
      <tr>
         <?php $__currentLoopData = $companystudents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $companystudent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php echo e($companystudent->id_company); ?>

         <?php if(($companystudent->id_company) === ($company->id_company)): ?>
         <?php 
          $fulltime=substr(($companystudent->time_slot_value),0,5);
          $endTime = strtotime("+5 minutes", strtotime($companystudent->time_slot_value)); 
         ?>
        <th scope="row"><?php echo e($number_row); ?></th>
      <td><?php echo e($companystudent->time_slot_value); ?></td>
      <td><?php echo e($companystudent->firstName); ?></td>
      <td><?php echo e($companystudent->lastName); ?></td>
      <?php 
      $number_row++;
      ?>
      </tr>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php endif; ?>

<br><br>






<a role="button" class="btn btn-primary" href="javascript:window.print()">Print</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appAdmin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>