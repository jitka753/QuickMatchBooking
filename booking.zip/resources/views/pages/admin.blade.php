@extends('layouts.appAdmin')

@section('content')
    <h1>Welcome, {{Auth::user()->name}}</h1>
  
    <div class="row">
            <div class="col-sm-6">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Company</h5>
                  <p class="card-text"></p>
                  <a href="addcompany" class="btn btn-primary">Add Company</a>
                  <a href="companyevent" class="btn btn-primary">Sign Company To Event</a>

                </div>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="card">
                <div class="card-body">
                  <h5 class="card-title">Event participants</h5>
                  <p class="card-text"></p>
                  <a href="allstudents" class="btn btn-primary">All students</a>
                  <a href="companystudent" class="btn btn-primary">Company-students lists</a>
                </div>
              </div>
            </div>
          </div>
    
@endsection
