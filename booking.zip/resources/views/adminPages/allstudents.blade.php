@extends('layouts.appAdmin')

@section('content')
<h1>All Students</h1>

@if(count($students) >0) 
    <table id="printable" class="table table-bordered">
        <thead>
          <tr>
                @php 
                $number_row=1;
                @endphp
            <th scope="col"></th>
            <th scope="col">First Name</th>
            <th scope="col">Last Name</th>


          </tr>
        </thead>
        <tbody>
          <tr>
             @foreach($students as $student)
            <th scope="row">{{$number_row}}</th>
          <td>{{$student->name}}</td>
          <td>{{$student->studentLastName}}</td>
          @php 
          $number_row++;
          @endphp
          </tr>
          @endforeach
        </tbody>
    </table>
    @endif

    <br><br>

    <a href="javascript:window.print()">Print</a>
@endsection